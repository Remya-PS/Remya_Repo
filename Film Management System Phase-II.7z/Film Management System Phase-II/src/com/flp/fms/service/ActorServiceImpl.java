package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

//Actor Service Implementation
public class ActorServiceImpl implements IActorService {

	private IActorDao actorDao=new ActorDaoImplForDB();
	
	//method to get all actors
	@Override
	public List<Actor> getActors() {
		return actorDao.getActors();
	}

}
