package com.flp.fms.service;

import java.util.List;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//Film Service Implementation
public class FilmServiceImpl implements IFilmService{
	
private IFilmDao filmDao=new FilmDaoImplForDB();
	
	//Getting All Languages
	@Override
	public List<Language> getLanguages() {		
		return filmDao.getLanguages();
	}

	//Getting All Categories
	@Override
	public List<Category> getcategories() {		
		return filmDao.getCategories();
	}
	
	//Adding Film to Database
	@Override
	public void addFilm(Film film) {		
		filmDao.addFilm(film);		
	}
	
	//Getting All Film from Database
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	//Searching Film from film repository using Film Id
	@Override
	public Film searchFilm(int filmId) {
			
		return filmDao.searchFilm(filmId);
	}
	
	//Searching Film from film repository using Language
	@Override
	public List<Film> searchFilm(Language language) {
		
		return filmDao.searchFilm(language);
	}
	
	//Searching Film from film repository using Film Title
	@Override
	public Film searchFilm(String title) {
		
		return filmDao.searchFilm(title);
	}
	
	
	//Searching Film from film repository using Film Rating
	@Override
	public List<Film> searchFilmByRating(int rating) {
		
		return filmDao.searchFilmByRating(rating);
	}
	
	
	//Searching Film from film repository using Film Actor
	@Override
	public List<Film> searchFilm(Actor actor) {
		
		return filmDao.searchFilm(actor);
	}
	
	//Deleting Film Using Film Id
	@Override
	public void removeFilm(int filmId) {
		
		filmDao.removeFilm(filmId);
	}

	//Deleting Film Using Film Title
	@Override
	public void removeFilm(String title) {
		
		filmDao.removeFilm(title);
	}

	//Deleting Film Using Film Rating
	@Override
	public void removeFilmByRating(int rating) {
		
		filmDao.removeFilmByRating(rating);
	}

	//Deleting Film Using Actor
	@Override
	public void removeFilm(Actor actor) {
		
		filmDao.removeFilm(actor);
	}

	//Updating Film In Database
	@Override
	public void updateFilm(Film film) {
		filmDao.updateFilm(film);	
	}
	
}
