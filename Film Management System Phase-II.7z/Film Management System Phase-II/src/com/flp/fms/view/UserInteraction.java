package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

//User Data Prompting Class
public class UserInteraction {

	//Scanner Instance Creation
	Scanner sc = new Scanner(System.in);
	
	
	//Prompt User to enter Film Id
	public int readFilmId(){
		
		System.out.println("enter film id");
		return sc.nextInt();
	}
	
	
	//Prompt User to enter Film Title
	public String readTitle(){
			
		System.out.println("enter film title");
		String title = sc.nextLine();
		return title;
	}
	
	
	//Prompt User to enter Actor First Name
	public String readFirstName(){
			
		System.out.println("enter first name of Actor");
		return sc.next();
	}
	
	
	//Prompt User to enter Actor Last Name
	public String readLastName(){
				
		System.out.println("enter Last name of Actor");
		return sc.next();
	}
	
	//Prompt User to enter Film Rating
	public int readRating(){
				
		System.out.println("enter film rating");
		return sc.nextInt();
	}
	
	
	//adding Film To Film Repository with Languages, Category and Actors
	public Film addFilm(List<Language> languages,List<Category> categories,List<Actor> allActors){
		
		Film film = new Film();
		
		//Local variables
		String title;
		String releaseDate;
		Language originalLanguage;
		String rentalDuration;
		int length;
		int ratings;
		List<Language> otherLanguages;
		List<Actor> actors;
		Category category;
		
		boolean flag = false;
		
		//Getting Film Title and Validating it
		do{
			
			System.out.println("enter film title");
			title = sc.nextLine();
			
			flag = Validate.isValidTitle(title);
			
			if(!flag)
				System.out.println("Inavlid title. Enter a valid title!");
			
		}while(!flag);
		
		film.setTitle(title);
		
		//Prompt User to enter Film Description
		System.out.println("enter film description: ");
		film.setDescription(sc.nextLine());
		
		//Prompt User to enter Film Release Date and Validating 
		do{
			
			System.out.println("enter released date [dd-mmm-yyy]: ");
			releaseDate = sc.next();
			
			flag = Validate.isValidDateFormat(releaseDate);
			
			if(flag){
				
				Date currentDate = new Date();
				Date releaseYear = new Date(releaseDate);
				
				//Checking whether release date is on or before current date
				if(releaseYear.before(currentDate)||releaseYear.equals(currentDate))
					film.setReleaseYear(releaseYear);
				
				else{
					System.out.println("Invalid date. Release date should be on or before current date");
					flag = false;
				}
			}
			
			else
				System.out.println("Inavlid date format. Please enter correct format!");
			
		}while(!flag);
		
		//Prompt User to enter Film Rental Duration and Validating it
		do{
			
			System.out.println("enter rental duration [dd-mmm-yyyy]: ");
			rentalDuration = sc.next();
			
			flag = Validate.isValidDateFormat(rentalDuration);
			
			if(flag){
				
				Date rental_duration = new Date(rentalDuration);
				
				//checking whether rental duration is on or after release date
				if(film.getReleaseYear().before(rental_duration)||film.getReleaseYear().equals(rental_duration))
					film.setRentalDuration(rental_duration);
				
				else{
					System.out.println("Invalid date. Rental duration should be on or before release date");
					flag = false;
				}
			}
			
			else
				System.out.println("Inavlid date format. Please enter correct format!");
			
		}while(!flag);
		
		//Prompt User to enter Film Original Language
		System.out.println("enter orginal language");
		originalLanguage = selectLanguage(languages);
		film.setOriginalLanguage(originalLanguage);
				
		//Prompt User to enter Film Other Languages in which Film was Released
		String choice;
		otherLanguages = new ArrayList<>();
		System.out.println("Choose all the languages in which film is released");
		do{

			Language lang = selectLanguage(languages);
			
			//to check whether selected language is already added
			int flag1=0;
			if(!otherLanguages.isEmpty()){
				
				for(Language lan : otherLanguages){
					if(lan.equals(lang)){
						flag1=1;
						break;
					}	
				}
			}
			
			if(flag1!=1)
				otherLanguages.add(lang);
			else
				System.out.println("This language is already added. select another");
					
			System.out.println("do you want to enter another language? [y/n]");
			choice = sc.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				
		film.setLanguages(otherLanguages);		
		
		//Prompt User to enter Film Length and Validating it
		do{
			
			System.out.println("enter length of the film minutes: ");
			length = sc.nextInt();
			
			flag = Validate.isValidLength(length);
			
			if(!flag)
				System.out.println("Invalid length. Length must be between 0 and 1000");
		}while(!flag);
		
		film.setLength(length);
	
		//Prompt User to enter Film Replacement Cost and Validating it
		System.out.println("enter replacement cost: ");
		film.setReplacementCost(sc.nextDouble());
		
		//Prompt User to enter Film Category
		category = selectCategory(categories);
		film.setCategory(category);
		
		//Prompt User to enter Film Special Features
		System.out.println("enter special features: ");
		film.setSpecialFeatures(sc.next());
		
		//Prompt User to enter Film Rating and validating it
		do{
			
			System.out.println("enter rating for the film: ");
			ratings = sc.nextInt();
			
			flag = Validate.isValidRating(ratings);
			
			if(!flag)
				System.out.println("enter valid rating!");
			
		}while(!flag);
		
		film.setRatings(ratings);	
		
		//To Get All Actors acted in the Film
		actors = new ArrayList<>();
		System.out.println("Add all actors");
		do{

			Actor actor = selectActor(allActors);
			
			//to check whether selected actor is already added
			int flag1=0;
			if(!actors.isEmpty()){
				
				for(Actor act : actors){
					if(act.equals(actor)){
						flag1=1;
						break;
					}	
				}
			}
			
			if(flag1!=1)
				actors.add(actor);
			else
				System.out.println("This actor is already added. select another");
							
			System.out.println("do you want to enter another actor? [y/n]");
			choice = sc.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
						
		film.setActors(actors);
		
		return film;
	}
	
	//To Select Languages in which Film was Released
	public Language selectLanguage(List<Language> languages){
		
		Language selectedLanguage=null;
		boolean flag = false;
		
		do{	
			
			//Print Language Details
			System.out.println("\tLANGUAGES");
			for(Language language:languages)
				System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
			
			System.out.println("Choose Language:");
			int option=sc.nextInt();
			
			//Checking whether a valid language id
			for(Language language: languages)
			{
				if(option==language.getLanguage_Id())
				{
					flag=true;
					selectedLanguage=language;					
					break;
				}
			}
			
			//Print Error Message for invalid language id
			if(!flag)
				System.out.println("Please select valid Language Id!");
			
		}while(!flag);	
		
		return selectedLanguage;
	}
	
	
	//To Select Film Category
	public Category selectCategory(List<Category> categories){
		
		Category selectedCategory=null;
		boolean flag = false;
		
		do{	
			
			//Print Category Details
			System.out.println("\tCATEGORIES");
			for(Category category:categories)
				System.out.println(category.getCategory_Id() + "\t" + category.getCategory_name());
			
			System.out.println("Choose the Category:");
			int option=sc.nextInt();
			
			//Checking whether a valid language id
			for(Category category:categories)
			{
				if(option==category.getCategory_Id())
				{
					flag=true;
					selectedCategory=category;					
					break;
				}
			}
			
			//Print Error Message for invalid category id
			if(!flag)
				System.out.println("Please select valid category Id!");
			
		}while(!flag);	
		
		return selectedCategory;
	}
	
	//To select an Actor
	public Actor selectActor(List<Actor> allActors){
		
		Actor selectedActor = null;
		boolean flag = false;
		
		do{	
			
			//Print Actor Details
			System.out.println("\tACTORS");
			for(Actor actor: allActors)
				System.out.println(actor.getActorId() + "\t" + actor.getFirstName() + " " + actor.getLastName());
			
			System.out.println("Choose the Actor:");
			int option=sc.nextInt();
			
			//Checking whether the entered Actor Id is valid
			for(Actor actor: allActors)
			{
				if(option==actor.getActorId())
				{
					flag=true;
					selectedActor=actor;					
					break;
				}
			}
			
			//Print Error Message for invalid Actor Id
			if(!flag)
				System.out.println("Please select valid Actor Id!");
			
		}while(!flag);	
		
		
		return selectedActor;
	}
	
	//To List all Film from Database
	public void getAllFilm(Collection<Film> films){
		
		//getting all the films in the Database
		if(films.isEmpty())
			System.out.println("No Film Exists!");
		
		else{
			
			System.out.println("FILM ID"+ "\t" + " TITLE" + "\t" + "DESCRIPTION" +"\t"
				+ "RELEASE_YEAR" + "\t" + "ORIGINAL_LANGUAGE" + "\t" + "OTHER_LANGUAGES" + "\t"
				+ "RENTAL_DURATION"	+ "\t" + "LENGTH" + "\t" + "REPLACEMENT_COST" + "\t"
				+ "RATING" + "\t" + "SPECIAL_FEATURES" + "\t" + "ACTORS" + "\t" + "CATEGORY");
					
					
			for(Film film: films){
						
				printFilm(film);
			}
		}
	}
	
	//Displaying All Films
	public void printFilm(Film film){
		
		
		if (film!=null) {
			
			String otherLanguages = "";
			String allActors = "";
			//getting the name of all languages in which film is released
			for (Language language : film.getLanguages()) {

				otherLanguages = otherLanguages + language.getLanguage_Name() + ", ";
			}
			//getting the name of all the actors in the film
			for (Actor actor : film.getActors()) {

				allActors = allActors + actor.getFirstName() + " " + actor.getLastName() + ", ";
			}
			System.out.println("\n" + film.getFilmId() + "\t" + film.getTitle() + "\t" + film.getDescription() + "\t"
					+ film.getReleaseYear() + "\t" + film.getOriginalLanguage().getLanguage_Name() + "\t"
					+ otherLanguages + "\t" + film.getRentalDuration() + "\t" + film.getLength() + "\t"
					+ film.getReplacementCost() + "\t" + film.getRatings() + "\t" + film.getSpecialFeatures() + "\t"
					+ allActors + "\t" + film.getCategory().getCategory_name());
		}
		
		else
			System.out.println("Film does not exist!");
	
	}
}
