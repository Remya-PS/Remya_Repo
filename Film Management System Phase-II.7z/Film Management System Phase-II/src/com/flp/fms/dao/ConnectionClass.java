package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Connection Class For Access for all methods
public class ConnectionClass {

//Connection Class For Access for all methods
public Connection getConnection(){
		
		Connection connection = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/fms", "root", "Pass1234");
			
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		return connection;		
	}
		
	
}
