package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

//Actor DAO Interface
public interface IActorDao {

	public List<Actor> getActors();
	public ArrayList<Actor> displayActors();
}
