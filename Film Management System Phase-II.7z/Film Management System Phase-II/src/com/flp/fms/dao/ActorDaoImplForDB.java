package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

//Actor Dao Implementation
public class ActorDaoImplForDB implements IActorDao {

	//Getting All actors from Database
	@Override
	public List<Actor> getActors() {
		List<Actor> actors= new ArrayList<>();
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="select * from actor";
		PreparedStatement stmt;
		
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Actor actor=new Actor();
				
				actor.setActorId(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				actors.add(actor);
			}
			
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		
		return actors;
	}

	//To display actors to Search
	@Override
	public ArrayList<Actor> displayActors() {
		ConnectionClass conn = new ConnectionClass();
		Connection newconnection=  conn.getConnection();
		
		ArrayList<Actor> actors1 = new ArrayList<>();
		
		//execute query
		boolean flag=false;
		String sql = "select * from actor";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Actor actors = new Actor();
				
				actors.setActorId(rs.getInt(1));
				actors.setFirstName(rs.getString(2));
				actors.setLastName(rs.getString(3));
				actors1.add(actors);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return actors1;
	}
}


