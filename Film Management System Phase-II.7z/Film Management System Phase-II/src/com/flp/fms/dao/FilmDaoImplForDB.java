package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//Film DAO Implementation
public class FilmDaoImplForDB implements IFilmDao {
	

	HashMap<Integer, Film> filmRepository = new HashMap<>();
	
	//Getting all languages from Database
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages=new ArrayList<>();

		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		String sql="select * from LANGUAGE";
				
		PreparedStatement stmt;
		try {
			
				stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
			
				while(rs.next()){
				
					Language language = new Language();
					
					language.setLanguage_Id(rs.getInt(1));
					language.setLanguage_Name(rs.getString(2));
				
					languages.add(language);
				}
				
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return languages;
	}	
	
	//Getting all category from Database
	@Override
	public List<Category> getCategories() {
		
		List<Category> categories = new ArrayList<>();
	
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();

		String sql="select * from category";
		
		PreparedStatement stmt;
		try {
	
				stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
	
				while(rs.next()){
		
					Category category = new Category();
		
					category.setCategory_Id(rs.getInt(1));
					category.setCategory_name(rs.getString(2));
		
					categories.add(category);
				}
	
				con.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return categories;
	}

//-------------------------- ADD FILM TO DATABASE ---------------------------	
	
	//Adding Film to Database
	@Override
	public void addFilm(Film film) {

		//Establishing Database connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="insert into film(title,description,realeaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category) values(?,?,?,?,?,?,?,?,?,?)";
		;
		try{
			PreparedStatement pst=con.prepareStatement(sql);
						
			pst.setString(1, film.getTitle());
			pst.setString(2,film.getDescription());
			pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
			int language=film.getOriginalLanguage().getLanguage_Id();
			pst.setInt(4,language);
			pst.setDate(5,new java.sql.Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7, film.getReplacementCost());
			pst.setInt(8, film.getRatings());
			pst.setString(9, film.getSpecialFeatures());
			int category=film.getCategory().getCategory_Id();
			pst.setInt(10,category);
			
			int count=pst.executeUpdate();
			System.out.println(count);
			
			//insertion to film table if success
			if(count>0){
				
				//adding to third party tables
				int filmid=0;
				sql="select film_Id from film where title='"+film.getTitle()+"'";			
				PreparedStatement stmt=con.prepareStatement(sql);
				ResultSet rs=stmt.executeQuery();
				
				while(rs.next()){
					filmid=rs.getInt(1);
				}
				
				//insertion to film_actors table
				sql="insert into film_actors(film_Id,actorId) values(?,?)";
				pst = con.prepareStatement(sql);
				
				//setting all the actors in the film
				List<Actor> actors = film.getActors();				
				for(Actor act: actors){
					pst.setInt(1, filmid );
					pst.setInt(2, act.getActorId());
					
					count=pst.executeUpdate();
				}
				
				//insertion to film_language table
				sql="insert into film_language(film_Id,language_id) values(?,?)";
				pst = con.prepareStatement(sql);
				
				//setting all the languages in the film
				List<Language> languages = film.getLanguages();				
				for(Language lang: languages){
					pst.setInt(1, filmid );
					pst.setInt(2, lang.getLanguage_Id());
					
					count=pst.executeUpdate();
				}			
			}
		}catch(SQLException ex){
			ex.printStackTrace();
		}
}
	
	//-----------------------------------------LIST ALL FILMS----------------------------
	
	// Getting all films from Database and setting to Film
	@Override
	public List<Film> getAllFilms() {
		
		List<Film> filmList=new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="select * from film";
		PreparedStatement stmt;
		
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Film film=new Film();
				
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4));
				
				//Selecting language from Language Table				
				sql="select language_name from LANGUAGE where language_id="+rs.getInt(5);
				PreparedStatement pst1=con.prepareStatement(sql);
				ResultSet rs1=pst1.executeQuery();
				Language orglan=new Language();
				if(rs1.next()){
					orglan.setLanguage_Id(rs.getInt(5));
					orglan.setLanguage_Name(rs1.getString(1));
				}
				film.setOriginalLanguage(orglan);
				
				//Adding other languages in which the film was released
				List<Language> languages=new ArrayList<>();
				sql="select language_id from film_language where film_Id="+rs.getInt(1);
				PreparedStatement pst2=con.prepareStatement(sql);
				rs1=pst2.executeQuery();
				
				while(rs1.next()){
					String sql1="select * from LANGUAGE where language_id="+rs1.getInt(1);
					PreparedStatement stmt1=con.prepareStatement(sql1);
					ResultSet rs2=stmt1.executeQuery();
					
					while(rs2.next()){
						Language lan1=new Language();
						lan1.setLanguage_Id(rs2.getInt(1));
						lan1.setLanguage_Name(rs2.getString(2));
						
						languages.add(lan1);										
					}
				}
				
				film.setLanguages(languages);
				
				film.setRentalDuration(rs.getDate(6));
				film.setLength(rs.getInt(7));
				film.setReplacementCost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));	
				
				//Adding actors in the film
				List<Actor> actors=new ArrayList<>();
				sql="select actorId from film_actors where film_Id="+rs.getInt(1);
				PreparedStatement pst3=con.prepareStatement(sql);
				rs1=pst3.executeQuery();
				
				while(rs1.next()){
					String sql2="select firstName,lastName from actor where actorId="+rs1.getInt(1);
					PreparedStatement stmt2=con.prepareStatement(sql2);
					ResultSet rs4=stmt2.executeQuery();
					
					while(rs4.next()){
						Actor act=new Actor();
						act.setActorId(rs1.getInt(1));
						act.setFirstName(rs4.getString(1));
						act.setLastName(rs4.getString(2));
						
						actors.add(act);							
					}
				}
				film.setActors(actors);
				
				film.setSpecialFeatures(rs.getString(10));
				
				//selecting category from Category table
				sql="select category_name from category where category_id="+rs.getInt(11);
				PreparedStatement pst4=con.prepareStatement(sql);
				ResultSet rs5=pst4.executeQuery();
				Category cat=new Category();
				if(rs5.next()){
					cat.setCategory_Id(rs.getInt(11));
					cat.setCategory_name(rs5.getString(1));
				}
				film.setCategory(cat);
				
				filmList.add(film);
			}				
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	return filmList;
	}
	
	
	//--------------------------- DELETE FILM---------------------
	
		//To delete the Film from Database using Film Id
		@Override
		public void removeFilm(int filmId) {
			
			//Establishing Database connection
			ConnectionClass conClass = new ConnectionClass();
			Connection con = conClass.getConnection();
			
			String sql = "delete from film where film_Id="+filmId;
			
			try {
				
				PreparedStatement pst = con.prepareStatement(sql);
				int count=pst.executeUpdate();	
		
				if(count>0){
					
					sql = "delete from film_actors where film_Id="+filmId;
					pst = con.prepareStatement(sql);
					count = pst.executeUpdate();
					
					sql = "delete from film_language where film_Id="+filmId;
					pst = con.prepareStatement(sql);
					count = pst.executeUpdate();
				}
				
				con.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		//To delete the Film from Database using Film Title
		@Override
		public void removeFilm(String title) {
			
			//Establishing Database connection
			ConnectionClass conClass = new ConnectionClass();
			Connection con = conClass.getConnection();
			
			Film film = searchFilm(title);

			if(film != null){
				
				String sql = "delete from film where title='"+title+"'";
				
				try {
					
					PreparedStatement pst = con.prepareStatement(sql);
					int count=pst.executeUpdate();	
			
					if(count>0){
						
						sql = "delete from film_actors where film_Id="+film.getFilmId();
						pst = con.prepareStatement(sql);
						count = pst.executeUpdate();
						
						sql = "delete from film_language where film_Id="+film.getFilmId();
						pst = con.prepareStatement(sql);
						count = pst.executeUpdate();
					}					
					con.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}	
		
		//To delete the Film from Database using Film Rating
		@Override
		public void removeFilmByRating(int rating) {
			
			//Establishing Database connection
			ConnectionClass conClass = new ConnectionClass();
			Connection con = conClass.getConnection();
			
			List<Film> films = searchFilmByRating(rating);

			if(!films.isEmpty()){
				
				String sql = "delete from film where ratings="+rating;
				
				try {
					
					PreparedStatement pst = con.prepareStatement(sql);
					int count=pst.executeUpdate();	
			
					if(count>0){
						
						for(Film film:films){
							
							sql = "delete from film_actors where film_Id="+film.getFilmId();
							pst = con.prepareStatement(sql);
							count = pst.executeUpdate();
							
							sql = "delete from film_language where film_Id="+film.getFilmId();
							pst = con.prepareStatement(sql);
							count = pst.executeUpdate();
						}
					}
					
					con.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		
		//To delete the Film from Database using Film Actor
		@Override
		public void removeFilm(Actor actor) {
							
			//Establishing Database connection
			ConnectionClass conClass = new ConnectionClass();
			Connection con = conClass.getConnection();
			
			List<Film> films = searchFilm(actor);

			if(!films.isEmpty()){
								
				try {					
					
					for(Film film:films){
							
						String sql = "delete from film where film_Id="+film.getFilmId();
							
						PreparedStatement pst = con.prepareStatement(sql);
						int count=pst.executeUpdate();
							
						if(count>0){
							
							sql = "delete from film_actors where film_Id="+film.getFilmId();
							pst = con.prepareStatement(sql);
							count = pst.executeUpdate();
							
							sql = "delete from film_language where film_Id="+film.getFilmId();
							pst = con.prepareStatement(sql);
							count = pst.executeUpdate();
						}
					}
					
					con.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}			
		}

//-------------------------------------------- SEARCH FILM-------------------------------
		
	//Searching Film from Database Using Film Id
	@Override
	public Film searchFilm(int filmId) {
			
		Film film = new Film();
		
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "select * from film where film_Id="+filmId;
			
		try {
				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				
				//calling the createFilm() function 
				List<Film> allFilms = createFilmList(con, rs);

				if (!allFilms.isEmpty()) {
					
					for (Film flm :  allFilms) {
						film = flm;
					} 
				}
				else
					film=null;
				
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return film;
	}
	
	
	//Searching Film from Database Using Film Title
	@Override
	public Film searchFilm(String title) {
		
		Film film = new Film();
		
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "select * from film where title='"+title+"'";
			
		try {

				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				
				//calling the createFilm() function 
				List<Film> allFilms = createFilmList(con, rs);

				if (!allFilms.isEmpty()) {
					
					for (Film fil :  allFilms) {
						film = fil;
					} 
				}
				else
					film=null;
				
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return film;
	}
	
	
	//Searching Film from Database Using Film Rating
	@Override
	public List<Film> searchFilmByRating(int rating) {

		List<Film> selectedFilms = new ArrayList<>();
			
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "select * from film where ratings="+rating;
			
		try {

				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				
				//calling the createFilm() function 
				selectedFilms = createFilmList(con, rs);
				
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return selectedFilms;
	}

	
	//Searching Film from Database Using Film Language
	@Override
	public List<Film> searchFilm(Language language) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "SELECT DISTINCT * FROM film"
				+ " WHERE film_Id IN"
				+ " ( SELECT b.film_Id FROM film_language b"
					+ " WHERE b.language_id = "+ language.getLanguage_Id()
					+ " UNION "
					+ " SELECT c.film_Id FROM film c"
					+ " WHERE c.originalLanguage="+language.getLanguage_Id()	
				+")";
					
		try {

			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			
			//calling the createFilm() function 
			selectedFilms = createFilmList(con, rs);
			
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return selectedFilms;
	}
		
	//Searching Film from Database Using Actor
	@Override
	public List<Film> searchFilm(Actor actor) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "SELECT DISTINCT * FROM film"
				+ " WHERE film.film_Id IN"
				+ " ( SELECT film_Id FROM film_actors"
				+ " WHERE actorId=" + actor.getActorId()
				+ " )";
		
		
		try {

				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
			
				//calling the createFilm() function 
				selectedFilms = createFilmList(con, rs);
			
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return selectedFilms;
	}

//------------------------------FUNCTIONS FOR SEARCH ------------------------------------	
	
	//Function to Set value to Film Object from Database for Search Film 
	public List<Film> createFilmList(Connection con,ResultSet rs){
				
		List<Film> films = new ArrayList<>();
			
		try {
			
			while(rs.next()){
					
				Film film = new Film();
					
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4));
				
				//retrieving language name from language table
				Language lang = new Language();
				lang.setLanguage_Id(rs.getInt(5));
					
				String sql = "select language_name from LANGUAGE where language_id="+rs.getInt(5);
				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs1 = pst.executeQuery();
				while(rs1.next()){
					lang.setLanguage_Name(rs1.getString(1));
				}
					
				film.setOriginalLanguage(lang);
					
				film.setRentalDuration(rs.getDate(6));
				film.setLength(rs.getInt(7));
				film.setReplacementCost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));
				film.setSpecialFeatures(rs.getString(10));
					
				Category cat = new Category();
				cat.setCategory_Id(rs.getInt(11));				
				
				//retrieving category name from category table
				sql = "select category_name from category where category_id="+rs.getInt(11);
				pst= con.prepareStatement(sql);
				rs1= pst.executeQuery();
				while(rs1.next()){
					cat.setCategory_name(rs1.getString(1));
				}
					
				film.setCategory(cat);
						
				//Adding set of languages to film				
				List<Language> languages = getAllFilmLanguages(con, film.getFilmId());
				film.setLanguages(languages);
					
				//Adding set of Actors to film
				List<Actor> actors = getAllActorsOfFilm(con, film.getFilmId());
				film.setActors(actors);
					
				films.add(film);
			}
				
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return films;
	}
	
		
	//Getting all Languages in which Film was released
	public List<Language> getAllFilmLanguages(Connection con,int filmId){
			
		List<Language> languages = new ArrayList<>();				
				
		String sql1="select language_id from film_language where film_Id="+filmId;
		PreparedStatement stmt1;
		try {
					
			stmt1 = con.prepareStatement(sql1);
			ResultSet rs1 = stmt1.executeQuery();
					
			while(rs1.next()){
						
				//retrieving language from language table
				String sql2 = "select * from LANGUAGE where language_id="+rs1.getInt(1);
				PreparedStatement stmt2 = con.prepareStatement(sql2);
				ResultSet rs2 = stmt2.executeQuery();
						
				while(rs2.next()){
							
					Language lan = new Language();
					lan.setLanguage_Id(rs2.getInt(1));
					lan.setLanguage_Name(rs2.getString(2));
							
					languages.add(lan);
				}
			}
								
		} catch (SQLException e) {
				e.printStackTrace();
		}		
				
		return languages;
	}
		
			
	//Getting all Actors in the Film
	public List<Actor> getAllActorsOfFilm(Connection con,int filmId){
				
		List<Actor> actors = new ArrayList<>();
				
		String sql3="select actorId from film_actors where film_Id="+filmId;
		PreparedStatement stmt3;
		try {
					
			stmt3 = con.prepareStatement(sql3);			
			ResultSet rs3 = stmt3.executeQuery();
					
			while(rs3.next()){
						
				//retrieving actor from actor table
				String sql4 = "select * from actor where actorId="+rs3.getInt(1);
				PreparedStatement stmt4 = con.prepareStatement(sql4);
				ResultSet rs4 = stmt4.executeQuery();
						
				while(rs4.next()){
							
					Actor act = new Actor();
					act.setActorId(rs4.getInt(1));
					act.setFirstName(rs4.getString(2));
					act.setLastName(rs4.getString(3));
													
					actors.add(act);					
				}
			}	
					
		} catch (SQLException e) {
			e.printStackTrace();
		}			
				
		return actors;
	}
	
//---------------------------- UPDATE FILM ---------------------------------------	
	
	//To update the Film in Database
	@Override
	public void updateFilm(Film film) {
			
		//Establishing Database connection
		ConnectionClass conn = new ConnectionClass();		
		Connection con=  conn.getConnection();		
		
		//Query to set updated values of all fields in database
		 String sql="Update film Set title=?,description=?,realeaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where film_Id="+film.getFilmId();
		 
		 try {
			 	PreparedStatement pst = con.prepareStatement(sql);
				
				pst.setString(1,film.getTitle() );	
				pst.setString(2,film.getDescription() );
				pst.setDate(3,new java.sql.Date(film.getReleaseYear().getTime()));
				pst.setInt(4,film.getOriginalLanguage().getLanguage_Id());
				pst.setDate(5,new java.sql.Date(film.getRentalDuration().getTime()));
				pst.setInt(6,film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				Category cat=film.getCategory();
				pst.setInt(10,cat.getCategory_Id());
				int count=pst.executeUpdate();
				
				//if insertion to film table is success execute
				if(count>0){
					
					//insertion to third party tables					
							
					sql="delete from film_actors where film_Id="+film.getFilmId();
					PreparedStatement stmt = con.prepareStatement(sql);
					int count1= stmt.executeUpdate();
					
					sql="insert into film_actors(film_Id,actorId) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//setting all the actors in the film
					List<Actor> actors = film.getActors();			
					for(Actor act: actors){
						pst.setInt(1, film.getFilmId() );
						pst.setInt(2, act.getActorId());
						
						count=pst.executeUpdate();
					}
					
					sql="delete from film_language where film_Id="+film.getFilmId();
					stmt = con.prepareStatement(sql);
					count1= stmt.executeUpdate();
									
					sql="insert into film_language(film_Id,language_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the other languages
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, film.getFilmId());
						pst.setInt(2, lang.getLanguage_Id());
						
						count=pst.executeUpdate();
					}
				
			}} catch (SQLException e) {				
				e.printStackTrace();
			}		
	}

}

