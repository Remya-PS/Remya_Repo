package com.flp.fms.domain;

//Category Class
public class Category {
	
	//private fields
	private int category_Id;
	private String category_name;
	
	//no argument constructor
	public Category(){}
	
	//overloaded constructor
	public Category(int category_Id, String category_name) {
		super();
		this.category_Id = category_Id;
		this.category_name = category_name;
	}

	//Getters and Setters
	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	//toString method implementation
	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_name=" + category_name + "]";
	}
	
}
