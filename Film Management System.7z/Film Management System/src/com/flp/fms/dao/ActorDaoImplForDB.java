package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

//Actor Dao Implementation
public class ActorDaoImplForDB implements IActorDao {

	//Getting All actors from Database
	@Override
	public List<Actor> getActors() {
		List<Actor> actors= new ArrayList<>();
		
		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="select * from actor";
		PreparedStatement stmt;
		
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Actor actor=new Actor();
				
				actor.setActorId(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				actors.add(actor);
			}
			
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		
		return actors;
	}

	//To display actors to Search
	@Override
	public ArrayList<Actor> displayActors() {

		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		ArrayList<Actor> actors1 = new ArrayList<>();
		
		boolean flag=false;
		String sql = "select * from actor";
		PreparedStatement stmt;
		try {
			
			stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Actor actors = new Actor();
				
				actors.setActorId(rs.getInt(1));
				actors.setFirstName(rs.getString(2));
				actors.setLastName(rs.getString(3));
				actors1.add(actors);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return actors1;
	}

	//Adding Actors to Database
	@Override
	public int addActor(Actor actor) {
		int count=0;		

		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="insert into actor(firstName,lastName) values(?,?)";
		
		try {
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastName());
			count=pst.executeUpdate();
					return count;
				}
			catch (SQLException e) {
				e.printStackTrace();
			}
			return count;
}
		
//Getting Actor From Database using Actor Id
	@Override
	public Actor getActor(int actorId) {		

		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		Actor actor=new Actor();
		
		String sql="select * from actor where actorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, actorId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{				
				actor.setActorId(rs.getInt(1));
			    actor.setFirstName(rs.getString(2));
			    actor.setLastName(rs.getString(3));			    
			    
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return actor;
	}

	//Updating Actor in Database
	@Override
	public int updateActor(Actor actor) {
		
		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
				
		String sql="update actor set firstName=?,lastName=? where actorId=?";
		
		int count=0;

			try {
					PreparedStatement pst= con.prepareStatement(sql);
					pst.setString(1, actor.getFirstName());
					pst.setString(2, actor.getLastName());
					pst.setInt(3,actor.getActorId());
					count=pst.executeUpdate();

					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				return count;
	}

	//Deleting Actor From Database
	@Override
	public int deleteActor(int actorId) {
		int count=0;

		//Establishing Database Connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="select * from film_actors where actorId=?";
		String sql1="delete from actor where actorId=?";
		
		
		try {
			PreparedStatement pst1= con.prepareStatement(sql);
			pst1.setInt(1, actorId);
			ResultSet rs=pst1.executeQuery();
			if(rs.next())
				return 0;
			PreparedStatement pst= con.prepareStatement(sql1);
			pst.setInt(1, actorId);
			count=pst.executeUpdate();
			
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}
}
