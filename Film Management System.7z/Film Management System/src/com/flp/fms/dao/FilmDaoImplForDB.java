package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


//Film DAO Implementation
public class FilmDaoImplForDB implements IFilmDao {

	//Getting all languages from Database
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass connClass=new ConnectionClass();
		Connection con=connClass.getConnection();
		
		String sql="Select * from LANGUAGE";
		
		PreparedStatement stmt;
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Language language=new Language();
				
				language.setLanguage_Id(rs.getInt(1));
				language.setLanguage_Name(rs.getString(2));
				
				languages.add(language);
				
			}
			con.close();
			
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		
		return languages;
	}

	//Getting all category from Database
	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass connClass=new ConnectionClass();
		Connection con=connClass.getConnection();
		
		String sql="Select * from category";
		
		PreparedStatement stmt;
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Category category=new Category();
				
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_name(rs.getString(2));
				
				categories.add(category);
				
			}
			con.close();
			
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		
		return categories;
	}

	//---------------------------------------ADD FILM------------------------------------
	
	//Adding Film to Database
	@Override
	public void addFilm(Film film) {
		
		//Establishing Database connection
				ConnectionClass conClass=new ConnectionClass();
				Connection con=conClass.getConnection();
				
				String sql="insert into film(title,description,realeaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category) values(?,?,?,?,?,?,?,?,?,?)";
				;
				try{
					PreparedStatement pst=con.prepareStatement(sql);
								
					pst.setString(1, film.getTitle());
					pst.setString(2,film.getDescription());
					pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
					int language=film.getOriginalLanguage().getLanguage_Id();
					pst.setInt(4,language);
					pst.setDate(5,new java.sql.Date(film.getRentalDuration().getTime()));
					pst.setInt(6, film.getLength());
					pst.setDouble(7, film.getReplacementCost());
					pst.setInt(8, film.getRatings());
					pst.setString(9, film.getSpecialFeatures());
					int category=film.getCategory().getCategory_Id();
					pst.setInt(10,category);
					
					int count=pst.executeUpdate();
					System.out.println(count);
					
					//insertion to film table if success
					if(count>0){
						
						//adding to third party tables
						int filmid=0;
						sql="select film_Id from film where title='"+film.getTitle()+"'";			
						PreparedStatement stmt=con.prepareStatement(sql);
						ResultSet rs=stmt.executeQuery();
						
						while(rs.next()){
							filmid=rs.getInt(1);
						}
						
						//insertion to film_actors table
						sql="insert into film_actors(film_Id,actorId) values(?,?)";
						pst = con.prepareStatement(sql);
						
						//setting all the actors in the film
						List<Actor> actors = film.getActors();				
						for(Actor act: actors){
							pst.setInt(1, filmid );
							pst.setInt(2, act.getActorId());
							
							count=pst.executeUpdate();
						}
						
						//insertion to film_language table
						sql="insert into film_language(film_Id,language_id) values(?,?)";
						pst = con.prepareStatement(sql);
						
						//setting all the languages in the film
						List<Language> languages = film.getLanguages();				
						for(Language lang: languages){
							pst.setInt(1, filmid );
							pst.setInt(2, lang.getLanguage_Id());
							
							count=pst.executeUpdate();
						}			
					}
					con.close();
					
				}catch(SQLException ex){
					ex.printStackTrace();
		}
				
	}
	
	//--------------------------------------LIST ALL FILMS---------------------------------
	
	// Getting all films from Database and setting to Film
	@Override
	public List<Film> getAllFilms() {
		List<Film> filmList=new ArrayList<>();
			
		//Establishing Database connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="select * from film";
		PreparedStatement stmt;
		
		try{
			stmt=con.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				Film film=new Film();
				
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4));
				
				//Selecting language from Language Table				
				sql="select language_name from LANGUAGE where language_id="+rs.getInt(5);
				PreparedStatement pst1=con.prepareStatement(sql);
				ResultSet rs1=pst1.executeQuery();
				Language orglan=new Language();
				if(rs1.next()){
					orglan.setLanguage_Id(rs.getInt(5));
					orglan.setLanguage_Name(rs1.getString(1));
				}
				film.setOriginalLanguage(orglan);
				
				//Adding other languages in which the film was released
				List<Language> languages=new ArrayList<>();
				sql="select language_id from film_language where film_Id="+rs.getInt(1);
				PreparedStatement pst2=con.prepareStatement(sql);
				rs1=pst2.executeQuery();
				
				while(rs1.next()){
					String sql1="select * from LANGUAGE where language_id="+rs1.getInt(1);
					PreparedStatement stmt1=con.prepareStatement(sql1);
					ResultSet rs2=stmt1.executeQuery();
					
					while(rs2.next()){
						Language lan1=new Language();
						lan1.setLanguage_Id(rs2.getInt(1));
						lan1.setLanguage_Name(rs2.getString(2));
						
						languages.add(lan1);										
					}
				}
				
				film.setLanguages(languages);
				
				film.setRentalDuration(rs.getDate(6));
				film.setLength(rs.getInt(7));
				film.setReplacementCost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));	
				
				//Adding actors in the film
				List<Actor> actors=new ArrayList<>();
				sql="select actorId from film_actors where film_Id="+rs.getInt(1);
				PreparedStatement pst3=con.prepareStatement(sql);
				rs1=pst3.executeQuery();
				
				while(rs1.next()){
					String sql2="select firstName,lastName from actor where actorId="+rs1.getInt(1);
					PreparedStatement stmt2=con.prepareStatement(sql2);
					ResultSet rs4=stmt2.executeQuery();
					
					while(rs4.next()){
						Actor act=new Actor();
						act.setActorId(rs1.getInt(1));
						act.setFirstName(rs4.getString(1));
						act.setLastName(rs4.getString(2));
						
						actors.add(act);							
					}
				}
				film.setActors(actors);
				
				film.setSpecialFeatures(rs.getString(10));
				
				//selecting category from Category table
				sql="select category_name from category where category_id="+rs.getInt(11);
				PreparedStatement pst4=con.prepareStatement(sql);
				ResultSet rs5=pst4.executeQuery();
				Category cat=new Category();
				if(rs5.next()){
					cat.setCategory_Id(rs.getInt(11));
					cat.setCategory_name(rs5.getString(1));
				}
				film.setCategory(cat);
				
				filmList.add(film);
			}	
			con.close();
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	return filmList;
	}

	//-------------------------------------------DELETE FILM--------------------------------
	
	//To delete the Film from Database
	@Override
	public int removeFilm(int filmId) {
		int count=0;
		
		//Establishing Database connection
		ConnectionClass conClass=new ConnectionClass();
		Connection con=conClass.getConnection();
		
		String sql="delete from film_language where film_Id=?";
		String sql1="delete from film_actors where film_Id=?";
		String sql2="delete from film where film_Id=?";
		
		PreparedStatement pst;
		PreparedStatement pst1;
		PreparedStatement pst2;
		try {
			pst=con.prepareStatement(sql);
			pst.setInt(1, filmId);
			count=pst.executeUpdate();
			
			pst1=(PreparedStatement) con.prepareStatement(sql1);
			pst1.setInt(1, filmId);
			count=pst1.executeUpdate();
			
			pst2=(PreparedStatement) con.prepareStatement(sql2);
			pst2.setInt(1, filmId);
			count=pst2.executeUpdate();
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		return count;
	}
	
	
	//------------------------------------------SEARCH FILM--------------------------------
	
	//To display Languages for Search
	@Override
	public ArrayList<Language> displayLanguages() {
		ArrayList<Language> languages = new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass conn = new ConnectionClass();
		Connection newconnection=  conn.getConnection();

		boolean flag=false;
		String sql = "select * from LANGUAGE";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Language language = new Language();
				
				language.setLanguage_Id(rs.getInt(1));
				language.setLanguage_Name(rs.getString(2));
				languages.add(language);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return (ArrayList<Language>) languages;
	}

	//To display Category for Search
	@Override
	public ArrayList<Category> displayCategory() {
		ArrayList<Category> categorys = new ArrayList<>();
		
		//Establishing Database connection
		ConnectionClass conn = new ConnectionClass();
		Connection newconnection=  conn.getConnection();

		boolean flag=false;
		String sql = "select * from category";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Category category = new Category();
				
			   category.setCategory_Id(rs.getInt(1));
			   category.setCategory_name(rs.getString(2));
			
			   categorys.add(category);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return categorys;
	}

	// To Search a Film Based on given criteria
	@Override
	public ArrayList<Film> searchfilm(Film film) {
		
		//Establishing Database connection
		ConnectionClass conn = new ConnectionClass();
		Connection con=  conn.getConnection();

		int count=0;
		String sql="select * from film where";
		ArrayList<Film> films=new ArrayList<Film>();
		System.out.println(film);
		
		//if film list is not null do the search
		if(film!=null)
		{
			//add film id along with the query
			if(film.getFilmId()>0)
			{
				sql+=" film_Id="+film.getFilmId();
				count=1;
			}
			
			//add title with the query
			if(film.getTitle()!=null)
			{
				if(count==1)
				{
					sql+=" and title='"+film.getTitle()+"'";
				}
				else
				{
					sql+=" title='"+film.getTitle()+"'";
				}
				count=2;
			}
		
			// add Ratings with the Query
			if(film.getRatings()>0)
			{
				if(count==1||count==2)
				{
					sql+=" and ratings="+film.getRatings();
				}
				else
				{
					sql+=" ratings="+film.getRatings();
				}
				count=3;
			}
			
			//To search all those films in which the actor acted
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
				List<Actor> act=film.getActors();
				for(Actor a:act)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and film_Id In(Select film_Id from film_actors where actorId="+actor.getActorId()+")";
					
				}else
				{
				sql+=" film_Id In(Select film_Id from film_actors where actorId="+actor.getActorId()+")";
				}
				count=4;
			}
			
			//To search all those films released in the selected language			
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language la:langs)
					lang=la;
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and( film_Id In(Select film_Id from film_language where language_id="+lang.getLanguage_Id()+") or film_Id In (Select film_Id from film where originalLanguage="+lang.getLanguage_Id()+"))";
					
				}else
				{
				sql+=" ( film_Id In(Select film_Id from film_language where language_id="+lang.getLanguage_Id()+") or film_Id In (Select film_Id from film where originalLanguage="+lang.getLanguage_Id()+"))";
				
				}
				count=5;
			}
		
			//To add release year with query
			if(film.getReleaseYear()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" and realeaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				else
				{
					sql+=" and realeaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				count=6;
			}
			
				//list all films after search						
				boolean flag=false;
				
				PreparedStatement stmt;
				PreparedStatement stmt1;
				PreparedStatement stmt2;
				PreparedStatement stmt3;
				PreparedStatement stmtt3;
				PreparedStatement stmt4;
				PreparedStatement stmtt4;
				try {
					
					stmt = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery();	
					
					while(rs.next())
					{
						Film film1 =new Film();
						
					//get all values of film
					   film.setFilmId(rs.getInt(1));
					   film.setTitle(rs.getString(2));
					   film.setDescription(rs.getString(3));
					   film.setReleaseYear(rs.getDate(4));
					   
					 //get original language
					   String sql3="select * from LANGUAGE where language_id="+rs.getString(5);
					   stmt2 = con.prepareStatement(sql3);
					   ResultSet rs2 = stmt2.executeQuery();	
					   
					   while(rs2.next())
					   {
					   Language lan = new  Language();
					  
					   lan.setLanguage_Name(rs2.getString(2));
					   film.setOriginalLanguage( lan);
					   }
					  
					   //get all languages
					   String sql4="select language_id from film_language where film_Id="+rs.getInt(1);
					   stmt3 = con.prepareStatement(sql4);
					   ResultSet rs3 = stmt3.executeQuery();
					   List <Language> languagelist = new ArrayList<>();
					   while(rs3.next()){
						   
					   //select from language table
					   String sqll5= "select language_name from LANGUAGE where language_id="+rs3.getInt(1);
					   stmtt3 = con.prepareStatement(sqll5);
					   ResultSet rss3 = stmtt3.executeQuery();						  
					   
					   while(rss3.next())
					   {
						Language language = new Language();
						language.setLanguage_Name(rss3.getString(1));
					    language.setLanguage_Id(rs3.getInt(1));
						languagelist.add(language);
					 
					   }}
					   
					   film.setRentalDuration(rs.getDate(6));
					   film.setLength(rs.getInt(7));
					   film.setReplacementCost(rs.getDouble(8));
					   film.setRatings(rs.getInt(9));
					   film.setSpecialFeatures(rs.getString(10));
					   
					   //get category
					   String sql2= "select * from category where category_id="+rs.getString(11);
					   stmt1 = con.prepareStatement(sql2);
					   ResultSet rs1 = stmt1.executeQuery();	
					   Category cat = new Category();
					   while(rs1.next())
					   {
						   cat.setCategory_name(rs1.getString(2));
						   film.setCategory(cat);
					   }
					   
					   //get all actors
					   String sql6="select actorId from film_actors where film_Id="+rs.getInt(1);
					   stmt4 = con.prepareStatement(sql6);
					   ResultSet rs4 = stmt4.executeQuery();
					   List <Actor> actorlist = new ArrayList<>();
					   
					   while(rs4.next())
					   {
						   //select from the actor table
						   String sqll7= "select firstName,lastName from actor where actorId="+rs4.getInt(1);
						   stmtt4 = con.prepareStatement(sqll7);
						   ResultSet rss4 = stmtt4.executeQuery();						   
					   
					   Actor actor= new Actor();
					   while(rss4.next())
					   {
						  actor.setFirstName(rss4.getString(1));
						  actor.setLastName(rss4.getString(2));
						  actorlist.add(actor);					     
					   }}
					   
					   film.setLanguages(languagelist);
					   film.setActors(actorlist);
					   films.add(film);
					}
					  
					con.close();
			       }
					
					catch (SQLException e) {
						e.printStackTrace();
					}	
				}
		return films;
	}

	//------------------------------------------UPDATE FILM---------------------------
	
	//To update the Film in Database
	@Override
	public Boolean updateFilm(Film film ) {

		//Establishing Database connection
		ConnectionClass conn = new ConnectionClass();		
		Connection con=  conn.getConnection();		
		
		//Query to set updated values of all fields in database
		 String sql="Update film Set title=?,description=?,realeaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where film_Id="+film.getFilmId();
		 
		 try {
			 	PreparedStatement pst = con.prepareStatement(sql);
				
				pst.setString(1,film.getTitle() );	
				pst.setString(2,film.getDescription() );
				pst.setDate(3,new java.sql.Date(film.getReleaseYear().getTime()));
				pst.setInt(4,film.getOriginalLanguage().getLanguage_Id());
				pst.setDate(5,new java.sql.Date(film.getRentalDuration().getTime()));
				pst.setInt(6,film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				Category cat=film.getCategory();
				pst.setInt(10,cat.getCategory_Id());
				int count=pst.executeUpdate();
				
				//if insertion to film table is success execute
				if(count>0){
					
					//insertion to third party tables					
							
					sql="delete from film_actors where film_Id="+film.getFilmId();
					PreparedStatement stmt = con.prepareStatement(sql);
					int count1= stmt.executeUpdate();
					
					sql="insert into film_actors(film_Id,actorId) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//setting all the actors in the film
					List<Actor> actors = film.getActors();			
					for(Actor act: actors){
						pst.setInt(1, film.getFilmId() );
						pst.setInt(2, act.getActorId());
						
						count=pst.executeUpdate();
					}
					
					sql="delete from film_language where film_Id="+film.getFilmId();
					 stmt = con.prepareStatement(sql);
					 count1= stmt.executeUpdate();
									
					sql="insert into film_language(film_Id,language_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the other languages
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, film.getFilmId());
						pst.setInt(2, lang.getLanguage_Id());
						
						count=pst.executeUpdate();
					}
				
			}} catch (SQLException e) {				
				e.printStackTrace();
			}		
		 return null;
		 
	}

}
	