package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SearchFilmNameServlet
 */
public class SearchFilmNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService =new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		ArrayList<Language> languages=filmService.displayLanguages();
		ArrayList<Actor>actors=actorService.displayActors();
		ArrayList<Category>category=filmService.displayCategory();
		
		PrintWriter out=response.getWriter();
		
		//Generating Form to display Search criterias
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset='ISO-8859-1'>");
		out.println("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
				//+"<script type='text/javascript' src='script/validate.js'></script>"
				+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				+"<script type='text/javascript' src='script/datepick.js'></script>"
				+"<title>Search Film Form</title>"
				+"</head>");
		out.println("<body id='searchfilm1'>");
		out.println("<form name='searchfilm' action='SearchAllFilmServlet'>");
		out.println("<div>");
		out.println("<table>");
		out.println("<tr>"
					+"<td>");
		out.println("Search by FilmId:<input type='textbox' name='byId'/> ");
		out.println("</td>"
					+"</tr>");
		out.println("<tr>"
					+"<td>");
		
		out.println("Search by Rating:<input type='textbox' name='byRating'/> ");
		out.println("</td>"
					+"</tr>");
		out.println("<tr>"
					+ "<td>");
		out.println("Search by Release Date:<input type='textbox' id='datepicker1' align='center' name='byDate'/> ");
		out.println("</td>"
					+"</tr>");
		out.println("<tr>"
					+"<td>");
		out.println("Search by Title:<input type='textbox' align='center' name='byTitle'/> ");
		out.println("</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>");
		
		out.println("Search by Languages:<select name='byLanguage'>"
		+"<option value='0'>--Select--</option>");
		  for(Language lang:languages){
		out.println("<option value='"+ lang.getLanguage_Id()+"'>"
					+lang.getLanguage_Name()+ "</option>");	
		   }
		out.println("</select>");
		out.println("</td></tr>");
	
		out.println("<tr><td>");
		out.println("Search by Actor:<select name='byActor'>"
				+"<option value='0'>--Select--</option>");
		for(Actor act: actors)
		{
			out.println("<option value='"+act.getActorId()+"'>"
					+act.getFirstName()+" "+act.getLastName()
					+"</option>");
			
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>"
				+ "<tr>"
				+ "<td>"
				+ "<input type='submit' class='myBtn' value='search' name='search'>"
				+ "</td>"
				+ "</tr>");
		
		out.println("</table>");
		out.println("</div>");
	
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
}
	
