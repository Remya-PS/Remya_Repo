package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class AddNewFilmServlet
 */
public class AddNewFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AddNewFilmServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();	
				
		IFilmService filmService=new FilmServiceImpl();
		Film film=new Film();
		
		//Setting the data from all form elements into database
		film.setTitle(request.getParameter("filmtitle"));
		
		film.setDescription(request.getParameter("desc"));
		
		Date releaseDate=new Date(request.getParameter("reldate"));		
		film.setReleaseYear(releaseDate);
		
		Language lang=new Language();
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orglang")));
		film.setOriginalLanguage(lang);
				
		List<Language> langList = new ArrayList<>();
		String[] languages=request.getParameterValues("othlang");
		
		for(String langid: languages){
			Language lan = new Language();
			lan.setLanguage_Id(Integer.parseInt(langid));
			langList.add(lan);
		}
		System.out.println(langList);
		film.setLanguages(langList);
		
		Date rentalDate=new Date(request.getParameter("rendur"));		
		film.setRentalDuration(rentalDate);
		
		film.setLength(Integer.parseInt(request.getParameter("length")));
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("cost")));
		
		film.setRatings(Integer.parseInt(request.getParameter("rate")));
		
		film.setSpecialFeatures(request.getParameter("spcl"));		
		
		Category cat=new Category();
		cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);			
		
		List<Actor> actorList=new ArrayList<>();
		String[] actors=request.getParameterValues("actors");
				
		for(String actid:actors){
			Actor actor=new Actor();
			actor.setActorId(Integer.parseInt(actid));
			actorList.add(actor);
		}
		film.setActors(actorList);
			
		filmService.addFilm(film);
		
		out.println("Film added!");		
		
	}

}
