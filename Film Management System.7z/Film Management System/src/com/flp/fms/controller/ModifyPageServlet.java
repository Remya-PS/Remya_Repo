package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyPageServlet
 */
public class ModifyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService=new FilmServiceImpl();
		PrintWriter out=response.getWriter();
		
		//Getting all films to Display to update film
		List<Film> films=filmService.getAllFilms();
	
		//Generating table display films from Database
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"				
				+ "</head>"
				+ "<body id='updatefilm2>"
				+ "<div style='margin-left:500px;'>  </div>"
				+"<h3 align='center'>Update Film</h3>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Title </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year</th>"
				+ "<th>	Original Language</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages </th>"
				+ "<th> Actors </th>"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost </th>"
				+ "<th>	Category </th>"
				+ "<th>	Edit </th>"
				+ "</tr>");
		
		//displaying films from Database to update
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilmId()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				
				List<Language>langs=new ArrayList<>();
				langs=film.getLanguages();
				//System.out.println("This is other Languages"+film.getLanguages());
				out.println("<td>");
				for(Language lang:langs)
					out.println(lang.getLanguage_Name());
				out.println("</td>");
				
				List<Actor> actors =new ArrayList<>();
				actors=film.getActors();
				System.out.println("This is actors"+film.getActors());
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getFirstName()+" "+act.getLastName());
				out.println("</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_name()+"</td>");
				//System.out.println("This is Film Id "+film.getFilmId());
				out.println("<td><a href='ModifyServlet?filmid="+film.getFilmId()+"'>Update</a></td>");
								
				//System.out.println("This is 2nd time Film Id "+film.getFilmId());
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}

}
		