package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class CreateFilmNameServlet
 */
public class CreateFilmNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		IFilmService filmService=new FilmServiceImpl();
		
		//getting List of actors,categories and languages
		List<Actor> actors=filmService.getActors();
		List<Category> categories=filmService.getCategory();
		List<Language> languages=filmService.getLanguages();
		
		//Generating the Form for Prompting Film Information
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset='ISO-8859-1'>");
		out.println("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
				+"<script type='text/javascript' src='script/validate.js'></script>"
				+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				+"<script type='text/javascript' src='script/datepick.js'></script>"
				+"<title>Add Film Form</title>"
				+"</head>");
			
		out.println("<body id='createfilm'>"
				+"<form name='film' method='post' action='AddNewFilmServlet' onsubmit='return validateForm()' >"
				+"<h3 style='color:blue;'><u>Add New Film Form</u></h3>"
				+"<h5>(Fill All details marked *)</h5>"			
				+"<table>"
				+"<tr>"
				+"<td>Title*:</td>"
				+"<td><input type='text' name='filmtitle' id='title' size=20></td>"
				+"<td><div id='title_val' class='errMsg'></div></td>"
				+"</tr>"
				+"<tr>"
				+"<td>Description:</td>"
				+"<td><textarea name='desc' rows='5' cols='22'></textarea></td>"
				+"</tr>");
		
		out.println("<tr>"
				+"<td>Release Year*:</td>"
				+"<td><input type='text' id='datepicker1' name='reldate' size='20'></td>"
				+"</tr>"
				);
		
		out.println("<tr>"
				+"<td>Original Languages*:</td>"
				+"<td><select name='orglang'>");
		
		//getting language Id and language Name from Database to show in drop-down
		for(Language lang:languages){
		out.println("<option value= " + lang.getLanguage_Id() + ">" + lang.getLanguage_Name() +"</option>");
		}
		out.println("</select>"	
				+"</td>"
				+"</tr>");
		
		out.println("<tr>"
				+"<td>Choose Other Languages:</td>"
				+"<td>");
		
		//getting language Id and language Name from Database to show in checkbox
		for(Language lang:languages){
		out.println("<input type='checkbox' name='othlang' value="+lang.getLanguage_Id()+">"+lang.getLanguage_Name()+"</br>");
		}
		out.println("</tr>");
		
		out.println("<tr>"
				+"<td>Rental Duration*:</td>"
				+"<td><input type='text' id='datepicker2' name='rendur' size='20'></td>"
				+"<td><div id='rental_val' class='errMsg'></div></td>"
				+"</tr>"
				);	
		
		out.println("<tr>"
				+"<td>Length of Film in Minutes*:</td>"
				+"<td><input type='text' name='length' size='20'></td>"
				+"<td><div id='length_val' class='errMsg'></div></td>"
				+"</tr>"
				);
		
		out.println("<tr>"
				+"<td>Replacement Cost*:</td>"
				+"<td><input type='text' name='cost' size='20'></td>"
				+"<td><div id='cost_val' class='errMsg'></div></td>"
				+"</tr>");
		
		out.println("<tr>"
		+"<td>Rating*:</td>"
		+"<td><input type='text' name='rate' size='20'></td>"
		+"<td><div id='rate_val' class='errMsg'></div></td>"
		+"</tr>");
		
		out.println("<tr>"
		+"<td>Special Features:</td>"
		+"<td><textarea name='spcl' rows='5' cols='22'></textarea></td>"
		+"<tr>");
		
		out.println("<tr>"
				+"<td>Select Actors*:</td>"
				+"<td><select name='actors' multiple>");
		
		//getting Actor Id and Actor Name from Database to show in multiple select
		for(Actor act:actors)	{
			out.println("<option value= " + act.getActorId() + ">" +" "+ act.getFirstName()+act.getLastName() +"</option>");
		}
		out.println("</select></td>"
				+"</tr>");
		
		out.println("<tr>"
				+"<td>Select Category:</td>"
				+"<td><select name='category'>");
		
		//getting Category Id and Category Name from Database to show in drop-down
		for(Category cat:categories){
			out.println("<option value= " + cat.getCategory_Id()+ ">" +" "+ cat.getCategory_name() +"</option>");
		}
		out.println("</select></td>"
				+"</tr>");	
		
		out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' class='myBtn' value='Add Film'>"
				+"<input type='reset' class='myBtn' value='Clear'></td>"
				+"<tr>");
		
		out.println("</table>"
				+"</form>"
				+"</body>"
				+"</html>");

	}

}
