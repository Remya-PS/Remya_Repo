package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyServlet
 */
public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	String filmId=request.getParameter("filmid");			
		
		System.out.println(filmId);
		
		SimpleDateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
		
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		
		ArrayList<Language> languages=filmService.displayLanguages();
		ArrayList<Actor> actors=actorService.displayActors();
		ArrayList<Category> category=filmService.displayCategory();
		
		PrintWriter out=response.getWriter();
		
		Film Film1=new Film();
		Film1.setFilmId(Integer.parseInt(filmId));
		List<Film> films=filmService.searchfilm(Film1);
		
		Film film=new Film();
		if(!films.isEmpty())
			for(Film flm:films)
				film=flm;
		
		//Generating form to update required film details with film from Database
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset='ISO-8859-1'>");
		out.println("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
				+"<script type='text/javascript' src='script/validate.js'></script>"
				+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				+"<script type='text/javascript' src='script/datepick.js'></script>"
				+"<title>Update Film Form</title>"
				+"</head>");
		
		out.println("<body id='updatefilm1'>"
			+"	<form name='film' method='get' action='ModifyingServlet'>"
			+"	<h3>Film Update Form</h3>"
			+"	<table>"			
			+"<tr><td><input type=text  name=filmid value='"+filmId+"' hidden><td><tr>");	
		
		out.println("<tr>"
			+"<td>Film Title:</td>"
			+"<td><input type='text' name='filmtitle' size='20' value="+film.getTitle()+" onmouseout='return isValidTitle()'>"
			+"<div id='title_val' class='errMsg'></div></td></td>"
			+"</tr>"
			+"<tr>");
		
		out.println("<td>Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmdescription' cols='25' >"+film.getDescription()+"</textarea>"
			+"</td>"
			+"</tr>");	
		
		out.println("<tr>"
			+"<td>Release Date:</td>"
			+"<td><input type='text' id='datepicker1' name='releasedate' size='20' value="+df.format(film.getReleaseYear())+" >"
			+"</td>"
			+"</tr>"
			+"<tr>");
		
		out.println("<td>Rental Duration:</td>"
			+"<td><input type='text' id ='datepicker2' name='rendur' size='20' value='"+df.format(film.getRentalDuration())+"'onmouseout='return isValidRentalDate()'>"
			+"<div id='rental_val' class='errMsg'></div></td>"
			+"</tr>"
			+"<tr>");
		
		out.println("<td>Film Duration:</td>"
			+"<td><input type='text' name='length' size='20'value="+film.getLength()+" onmouseout='return isValidLength()'>"
			+"<div id='length_val' class='errMsg'></div>"
			+"</td>"
			+"</tr>");
		
		out.println("<tr>"
			+"<td>Replacement Cost:</td>"
			+"<td><input type='text' name='cost' size='20' value="+film.getReplacementCost()+" onmouseout='return isValidNumber()'>"
			+"<div id='cost_val' class='errMsg'></div></td>"
			+"</tr>");
		
		out.println("<tr>"
			+"<td>Rating:</td>"
			+"<td>"
			+"<select name='rating' >");
				for(int i=1;i<5;i++)
					{	
						if(i==film.getRatings())
							out.println("<option value='"+i+"'selected>"+i+"</option>");
						else
							out.println("<option value='"+i+"'>"+i+"</option>");
					}					
		out.println("</select>"
			+"</td>"
			+"</tr>");
		
		out.println("<tr>"
			+"<td>Special Features:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmspecialfeatures' cols='25'>"+film.getSpecialFeatures()+"</textarea>"
			+"</td>"
			+"</tr>");					
					
		out.println("<tr>"
			+"<td>Actors:</td>"
			+"<td>"
			+"<select name='actors'  multiple >");
		
		List<Actor> actors1=(List<Actor>) film.getActors();
		ArrayList<String> actorName=new ArrayList<>();
		boolean temp=false;
		for(Actor actor:actors1)
		{
			actorName.add(actor.getFirstName()+" "+actor.getLastName());
		}
	
		for(Actor actor:actors)
		{
			temp=false;
			for(String actorname:actorName)
			{
				if((actor.getFirstName()+" "+actor.getLastName()).equals(actorname))
				{
					temp=true;	
				}	
		    }
			if(temp==true)
				out.println("<option value='"+actor.getActorId()+"' selected>"+actor.getFirstName()+" "+actor.getLastName()+"</option>");
			else
				out.println("<option value='"+actor.getActorId()+"'>"+actor.getFirstName()+" "+actor.getLastName()+"</option>");
		}
				
		out.println("</select>"
			+"</td>"		
			+"</tr>");
					
		out.println("<tr>"
			+"<td>Original Language:</td>"
			+"<td>"
			+"<select name='language'>");	
					for(Language language:languages)
						{
							if(language.getLanguage_Name().equals(film.getOriginalLanguage().getLanguage_Name()))
								out.println("<option value='"+language.getLanguage_Id()+"' selected>"+language.getLanguage_Name()+"</option>");
							else
								out.println("<option value='"+language.getLanguage_Id()+"'>"+language.getLanguage_Name()+"</option>");
							
						}
		out.println("</select>");
						
		out.println("</td>"
			+"</tr>"
			+"<tr>"
			+"<td>Other Languages:</td>"
			+"<td>"
			+"<select name='languages' multiple> ");
				for(Language language:languages)
						{
							int flag=0;
							for(Language lang:film.getLanguages())
								{
								if(lang.getLanguage_Id()==language.getLanguage_Id()){
									out.println("<option value='"+ language.getLanguage_Id()+"'selected>" + language.getLanguage_Name() +"</option>");
									flag=1;
									break;
								}
						}							
							if(flag!=1)								
									out.println("<option value='"+ language.getLanguage_Id()+"'>" + language.getLanguage_Name() +"</option>");							
							
						}
		out.println("</select>"					
			+"</select>"						
			+"</td>"
			+"</tr>"					
			+"<tr>");
		
		out.println("<td>Category:</td>"
			+"<td >"
			+"<select name='category'>");
					for(Category cat:category)
					{
						if(cat.getCategory_name().equals(film.getCategory().getCategory_name()))
							out.println("<option value='"+cat.getCategory_Id()+"' selected>"+cat.getCategory_name()+"</option>");
						else
							out.println("<option value='"+cat.getCategory_Id()+"'>"+cat.getCategory_name()+"</option>");
							
					}
		out.println("</select>"					
			+"</td>"
			+"</tr>");
		
		out.println("<tr>"
			+"<td></td>"
			+"<td><input type='submit' class='myBtn' value='Update'>"
			+"<input type='reset' class='myBtn' value='Clear'>"
			+"</td>"
			+"</tr>");
					
		out.println("</table>"
			+"</form>"
			+"</body>"
			+"</html>");
								
		Boolean flag=filmService.updateFilm(film);			
		
	}
}