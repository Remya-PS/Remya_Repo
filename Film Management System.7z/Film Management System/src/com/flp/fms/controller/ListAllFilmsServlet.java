package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ListAllFilmsServlet
 */
public class ListAllFilmsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		
		//Getting all films,languages and actors
		List<Film> films=filmService.getAllFilms();		
		List<Language> languages=filmService.getLanguages();
		List<Actor> actors=filmService.getActors();
		
			PrintWriter out=response.getWriter();
			
			// Generating Table to display all films
			out.println("<!DOCTYPE html");
			out.println("<html>"
					+"<head><title>List of All Films</title><head>"
					+"<body id='listfilm'>"
					+"<h2 align='center'>All Films in Database</h2>"
					+"<table align='center' border=1>"
					+"<tr>"
					+"<th>Film ID</th>"
					+"<th>Title</th>"
					+"<th>Description</th>"
					+"<th>Release Year</th>"
					+"<th>Original Language</th>"
					+"<th>Other Languages</th>"
					+"<th>Rental Duration</th>"
					+"<th>Length</th>"
					+"<th>Replacement Cost</th>"
					+"<th>Ratings</th>"
					+"<th>Actors</th>"
					+"<th>Special Features</th>"
					+"<th>Category</th>"
					+"</tr>"
					);
			
			List<Language> lang=new ArrayList<>();
			List<Actor> actor=new ArrayList<>();
			
			// Displaying all existing films from Database
			for(Film film:films){
								
			out.println("<tr>");
			out.println("<td>"+film.getFilmId()+"</td>"
						+"<td>"+film.getTitle()+"</td>"
						+"<td>"+film.getDescription()+"</td>"
						+"<td>"+film.getReleaseYear()+"</td>"
						+"<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");
			lang=film.getLanguages();
			out.println("<td>");
			for(Language lan:lang){
				
				out.println(lan.getLanguage_Name());
			}
			
			out.println("</td>");
			out.println("<td>"+film.getRentalDuration()+"</td>"
						+"<td>"+film.getLength()+"</td>"
						+"<td>"+film.getReplacementCost()+"</td>"
						+"<td>"+film.getRatings()+"</td>");
			actor=film.getActors();			
			out.println("<td>");
			for(Actor act:actor){	
				out.println(act.getFirstName()+" "+act.getLastName()+",");				
			}
			out.println("</td>");
			out.println("<td>"+film.getSpecialFeatures()+"</td>"
					+"<td>"+film.getCategory().getCategory_name()+"</td>");
			out.println("</tr>");
			}
			out.println("</table>"
					+ "</body>"
					+ "</html>");
	}

}

