package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class ModifyActorFormServlet
 */
public class ModifyActorFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		IActorService actorService=new ActorServiceImpl();
		
		List<Actor> actors=actorService.getActors();
				
		out.println("<html>");
		out.println("<head>"
				+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
				+"<script type='text/javascript' src='script/validate.js'></script>"
				+ "<title>Update Actors</title></head>"
				+ "<body id='updateactor'>"
				+ "<h2 align='center'>Update Actors</h2>"
				+ "<center>"
				+ "<table width=700px align=center>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+"<th>Edit</th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActorId()+"</td>");
				out.println("<td>"+actor.getFirstName()+"</td>");
				out.println("<td>"+actor.getLastName()+"</td>");
				out.println("<td><a href='ModifyingActorServlet?actorId="+actor.getActorId()+"' class='deleteFilm' >Update</a></td>");
				
				out.println("</tr>");
			}
				out.println("</table></center></body>");
	
				out.println("</html>");
	}

}

