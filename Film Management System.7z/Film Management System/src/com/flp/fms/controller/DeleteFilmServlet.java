package com.flp.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteFilmServlet
 */
public class DeleteFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Deleting the film of required filmId and Redirecting to DeleteFilmFormServlet  
		int fId=Integer.parseInt(request.getParameter("film_Id"));
		
		IFilmService filmService=new FilmServiceImpl();
		filmService.removeFilm(fId);;
		
			response.sendRedirect("DeleteFilmFormServlet");
		
	}

}



