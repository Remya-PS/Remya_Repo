package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteFilmFormServlet
 */
public class DeleteFilmFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		
		//Getting all films to Display to delete film
		List<Film> films=filmService.getAllFilms();
		
		PrintWriter out=response.getWriter();
			
		//generating Table to display all Films for Delete Table
			out.println("<!DOCTYPE html");
			out.println("<html>"
					+"<head>"
					+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
					+"<script type='text/javascript' src='script/validate.js'></script>"
					+ "<title>Delete Film</title><head>"
					+"<body id='deletefilm'>"
					+"<h2 align='center'>Delete Films</h2>"
					+"<table align='center' border=1>"
					+"<tr>"
					+"<th>Film ID</th>"
					+"<th>Title</th>"
					+"<th>Description</th>"
					+"<th>Release Year</th>"
					+"<th>Original Language</th>"
					+"<th>Other Languages</th>"
					+"<th>Rental Duration</th>"
					+"<th>Length</th>"
					+"<th>Replacement Cost</th>"
					+"<th>Ratings</th>"
					+"<th>Actors</th>"
					+"<th>Special Features</th>"
					+"<th>Category</th>"
					+"<th>Edit</th>"
					+"</tr>"
					);
			
			List<Language> languages=new ArrayList<>();
			List<Actor> actors=new ArrayList<>();
			
			//Getting and Displaying films from Database for delete Table
			for(Film film:films){
								
			out.println("<tr>");
			out.println("<td>"+film.getFilmId()+"</td>"
						+"<td>"+film.getTitle()+"</td>"
						+"<td>"+film.getDescription()+"</td>"
						+"<td>"+film.getReleaseYear()+"</td>"
						+"<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");
			languages=film.getLanguages();
			out.println("<td>");
			for(Language lang:languages){		
			
				out.println(lang.getLanguage_Name());
			}
			out.println("</td>");
			
			out.println("<td>"+film.getRentalDuration()+"</td>"
						+"<td>"+film.getLength()+"</td>"
						+"<td>"+film.getReplacementCost()+"</td>"
						+"<td>"+film.getRatings()+"</td>");
			
			actors=film.getActors();
			out.println("<td>");
			for(Actor act:actors){	
				out.println(act.getFirstName()+" "+act.getLastName()+",");				
			}
			out.println("</td>");
			
			out.println("<td>"+film.getSpecialFeatures()+"</td>"
					+"<td>"+film.getCategory().getCategory_name()+"</td>");
			
			//Directing to DeleteFilmservlet upon confirmation for delete
			out.println("<td><a href='DeleteFilmServlet?film_Id="+film.getFilmId()+"' onclick='return deleteFilmConfirmation()' class='deleteFilm'>Delete</a></td>");
			out.println("</tr>");
			}
			out.println("</table>"
					+ "</body>"
					+ "</html>");
	}
}
