package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyingServlet
 */
public class ModifyingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModifyingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();	
		IFilmService filmService=new FilmServiceImpl();
		
		Film film1=new Film();
		
		//getting and setting values from update form elements to film		
		film1.setFilmId(Integer.parseInt(request.getParameter("filmid")));
		
		film1.setTitle(request.getParameter("filmtitle"));
		
		film1.setDescription(request.getParameter("filmdescription"));
		
		System.out.println(request.getParameter("releasedate"));
		
		Date date=new Date(request.getParameter("releasedate"));		
		film1.setReleaseYear(date);	
		
		Language lang=new Language();		
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("language")));		
		film1.setOriginalLanguage(lang);	
		
		List<Language> langags=new ArrayList<>();
		String [] langlist=request.getParameterValues("languages");				
		for(String lang1:langlist)
		{
			Language langs=new Language();
			langs.setLanguage_Id(Integer.parseInt(lang1));
			langags.add(langs);
		}		
		film1.setLanguages(langags);		
		
		film1.setRentalDuration(new Date(request.getParameter("rendur")));
		
		film1.setLength(Integer.parseInt(request.getParameter("length")));
		
		Double fees=Double.parseDouble(request.getParameter("cost"));		
		film1.setReplacementCost(fees);
		
		film1.setRatings(Integer.parseInt(request.getParameter("rating")));
		
		film1.setSpecialFeatures(request.getParameter("filmspecialfeatures"));
		
		Category cat=new Category();
		cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film1.setCategory(cat);	
		
		List<Actor> actrs=new ArrayList<>();
		String [] actrlist=request.getParameterValues("actors");				
		for(String act:actrlist)
		{
			Actor actor1=new Actor();
			actor1.setActorId(Integer.parseInt(act));
			actrs.add(actor1);
		}
		film1.setActors(actrs);
		
		Boolean flag=filmService.updateFilm(film1);
	
		response.sendRedirect("ModifyPageServlet");
	}

	

}
