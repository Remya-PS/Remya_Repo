package com.flp.fms.test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//JUnit Testing Class
public class UnitTesting {
	
	IFilmDao filmDao=new FilmDaoImplForDB();
	IActorDao actorDao=new ActorDaoImplForDB();
	
	//-------------------------------------Test Actor-------------------------------------
	
		
	//1.Testing if Actor Object is Null
		/*@Test
		public void isActorObjectNull()
		{
			Actor actor=null;
			assertNotEquals(actor, actorDao.getActors());
		}*/
	
	//2.Testing if Actor Entry is not Duplicated
			/*@Test
			public void isDuplicateActorAllowed()
			{
				Actor actor=new Actor(1,"Sharukh","Khan");
				assertNotEquals(actor, actorDao.getActors());
			}*/
		
	//3.Testing If Get Actors Return All Actors
			/*@Test
			public void isReturningAllListOfActors()
			{
				assertEquals(10, actorDao.getActors().size());
				
			}*/
	//4.Testing if Get Actor returns All the List of Actor From Database 
	/*@Test
	public void isAllActorsReturnedSame()
	{
		
		List<Actor> actors=new ArrayList<>();
		
		actors.add(new Actor(1,"ShahRukh","Khan"));
		actors.add(new Actor(2,"Aamir","Khan"));
		actors.add(new Actor(3,"Kunchacho","Boban"));
		actors.add(new Actor(4,"Nivin","Pauly"));
		actors.add(new Actor(5,"Amitabh","Bachan"));
		actors.add(new Actor(6,"Kavya","Madhavan"));
		actors.add(new Actor(7,"Deepika","Padukone"));	
		actors.add(new Actor(8,"Madhuri","Dixit"));	
		actors.add(new Actor(9,"Manju","Warrier"));	
		actors.add(new Actor(10,"Priyanka","Chopra"));	
	
		assertEquals(actors, actorDao.getActors());
	}*/
	
	//5.Testing Add Actor adds the Actor to Database
		/*@Test
		public void addActorAddsOneActor()
		{
			Actor actor=new Actor();
			actor.setFirstName("Dulquer");
			actor.setLastName("Salmaan");
			assertEquals(1, actorDao.addActor(actor));
		}*/
		
	//6.Testing Get Actor retrieves the Actor from Database
		/*@Test
		public void isReturningOneActorForOneActorId()
		{
			Actor actor=new Actor();
			
			actor.setFirstName("ShahRukh");
			actor.setLastName("Khan");
			actor.setActorId(1);
			assertEquals(actor, actorDao.getActor(1));
		}*/	
		
		
	//7.Testing if Update Actor updates the proper Actor if ActorId Exists 
		/*@Test
		public void isUpdatingActorOfIfActorIdExists()
		{
			Actor actor=new Actor();
			
			actor.setFirstName("ShahRukh");
			actor.setLastName("Khan");
			actor.setActorId(1);
			assertEquals(1, actorDao.updateActor(actor));
		}*/
		
	//8.Testing if Delete Actor Does Not Allow to Delete if Actor Part of any Film
		/*@Test
		public void deleteActorNotAllowIfActorInAnyFilm()
		{
			assertEquals(0,actorDao.deleteActor(1));
		}*/
	
	
	//-------------------------------------Test Language----------------------------------
	
	
	//1.Testing ifLanguage Object is Null
		/*@Test
		public void isLanguageObjectIsNull() {
			
			Language language=null;
			assertNotEquals(language, filmDao.getLanguages());
			
		} */
	
	//2.testing if No Duplicate Language is Entered
		/*@Test
		public void ifNoDuplicateLanguage() {
			
			Language language=new Language(1,"English");
			assertNotEquals(language,filmDao.getLanguages());
			
		}*/
	
	//3.Testing if not Valid Language
		/*@Test
		public void isNotValidLanguage() {
			
			Language language=new Language(20,"ABC");
			assertNotEquals(language,filmDao.getLanguages());
			
		}*/
	
	
	//4.Testing if All Languages are retrieved from Language List
		/*@Test
		public void GetAllLanguages(){
			
			List<Language>languages=new ArrayList<>();
			
			languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Malayalam"));
			languages.add(new Language(4, "Tamil"));
			languages.add(new Language(5, "Kannada"));
			languages.add(new Language(6, "Telugu"));
			languages.add(new Language(7, "Marati"));
			languages.add(new Language(8, "Punjabi"));
			languages.add(new Language(9, "German"));
			languages.add(new Language(10, "Spanish"));
			
			assertEquals(languages, filmDao.getLanguages());
			
		}*/

	//-----------------------------------------Test Category------------------------------
	
	//1.Testing if Category object is Null
		/*@Test
		public void isCategoryObjectIsNull() {
			
			Category category=null;
			assertNotEquals(category, filmDao.getCategory());
			
		} */

	//2.Testing if no Duplicate Category is Added
		/*@Test
		public void noDuplicateActorEntry() {
			
			Category category=new Category(1,"Action");
			assertNotEquals(category,filmDao.getCategory());
			
		}*/
	
	//3.Testing if No such Category Exists
		/*@Test
		public void isNotValidCategory() {
			
			Category category=new Category(20,"ABC");
			assertNotEquals(category,filmDao.getCategory());
			
		}*/

			
	//-------------------------------------Test Film--------------------------------------

	//1.Testing If List of Languages Return the List of Language	
			/*@Test
			public void isReturningListOfLanguages()
			{
				assertEquals(10, filmDao.getLanguages().size());
			}*/
		
	
	//2.Testing If List of Category Return the List of Category	
		/*@Test
		public void isReturningListofCategory()
		{
			assertEquals(10, filmDao.getCategory().size());
			
		}*/
		
	
	//3.Testing Get All Films Return All Films from Database
		/*@Test
		public void isReturningAllFilmsForGetAll()
		{
			assertEquals(1,filmDao.getAllFilms().size());
		}*/
	
	
	//4.Testing if Delete Film Allows to delete if Film Does Not Exists
		/*@Test
		public void isFilmDeletedForGivenFilmId()
		{
			assertEquals(0,filmDao.removeFilm(3));
		}*/
		
	//5.Testing if Delete Film Allows to delete if Film Exists
		/*@Test
		public void isFilmDeletedForGivenFilmId()
		{
			assertEquals(1,filmDao.removeFilm(1));
		}*/
	
	//-------------------------------------------------------------------------------------
	//6.Testing if Update Film Allows to update if Film Exists
		/*@Test
		public void isFilmUpdatedForGivenFilmId()
		{		
			Film film=new Film();
			film.setTitle("Ravanaprabhu");
			film.setDescription("Second Part");
			
			Date date=new Date("04-apr-2016");
			film.setReleaseYear(date);
			
			Language lang=new Language();
			lang.setLanguage_Id(3);
			film.setOriginalLanguage(lang);
			
			Date date1=new Date("25-apr-2016");
			film.setRentalDuration(date1);
			
			film.setLength(120);
			film.setReplacementCost(200);
			film.setRatings(3);
			film.setSpecialFeatures("Interesting");
			
			Category category=new Category();
			category.setCategory_Id(5);
			film.setCategory(category);
			
			List<Language> langs=new ArrayList<>();
			Language lang1=new Language();
			Language lang2=new Language();
			lang1.setLanguage_Id(1);
			lang2.setLanguage_Id(2);
			langs.add(lang1);
			langs.add(lang2);
			film.setLanguages(langs);
			
			List<Actor> actors=new ArrayList<>();
			Actor actor1=new Actor();
			actor1.setActorId(1);
			actors.add(actor1);			
			film.setActors(actors);
			
			assertEquals(1,filmDao.updateFilm(film));
		}*/
		
	//Testing if Delete Actor Allow to Delete if Actor is Not Part of any Film
		/*@Test
		public void deleteActorAllowIfActorNotInAnyFilm()
		{
			assertEquals(9,actorDao.deleteActor(6));
		}*/
	
	
	
	
	//Testing if Film is Added
	/*@Test
	public void isaddFilmAddingFilm() throws Exception{
		
		Film film=new Film();
		film.setTitle("Ravanaprabhu");
		film.setDescription("Great");
		
		Date d=new Date("20-apr-2007");
		film.setReleaseYear(d);
		
		Language lang=new Language();
		lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		
		Date d1=new Date("30-may-2014");
		film.setRentalDuration(d1);
		
		film.setLength(123);
		film.setReplacementCost(234);
		film.setRatings(3);
		film.setSpecialFeatures("Actor both father and son");
		
		Category category=new Category();
		category.setCategory_Id(3);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(3);
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);
		
		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setActorId(4);
		Actor actor2=new Actor();
		actor2.setActorId(2);
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);
		
		assertEquals(1,filmDao.addFilm(film).size());
			
}*/

	//Testing if Film is Updated
	/*@Test
	public void isupdateFilmUpdatingFilm() throws Exception{
		
		Film film=new Film();
		film.setFilmId(3);
		film.setTitle("Ravanaprabhu");
		film.setDescription("Great");
		Date d=new Date("20-apr-2007");
		film.setReleaseYear(d);
		Language lang=new Language();
		lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		Date d1=new Date("30-may-2014");
		film.setRentalDuration(d1);
		film.setLength(11);
		film.setReplacementCost(1111);
		film.setRatings(2);
		film.setSpecialFeatures("#######");
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);
		
		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setActorId(3);
		Actor actor2=new Actor();
		actor2.setActorId(5);
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);
		assertEquals(1,filmDao.updateFilm(film));
				
	}
	*/
	
	//Testing if All Films are retrieved
	/*@Test
	public void isGetAllFilmsRetrievingAllFilms()
	{
		List<Film> films=new ArrayList<Film>();
		
		Film film=new Film();
		film.setFilmId(2);
		film.setTitle("Dil");
		film.setDescription("Great");
		
		SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");		
		Date date=new Date("20-apr-1988");
		Date date1=new Date(sf.format(date));		
		film.setReleaseYear(date);
		
		Language lang=new Language();
		lang.setLanguage_Name("English");
		film.setOriginalLanguage(lang);
		
		Date date2=new Date("30-may-1992");
		Date date3=new Date(sf.format(date2));
		film.setRentalDuration(date3);
		
		film.setLength(120);
		film.setReplacementCost(1200);
		film.setRatings(3);
		film.setSpecialFeatures("Interesting");
		
		Category category=new Category();
		category.setCategory_Id(5);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Name("Hindi");
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);
	
		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setFirstName("Aamir");
		actor1.setLastName("Khan");
		Actor actor2=new Actor();
		actor2.setFirstName("Madhuri");
		actor2.setLastName("Dixit");
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);
		films.add(film);
		
		assertEquals(film,filmDao.getAllFilms());
	}
	*/

}
