package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

//Actor Service Implementation
public class ActorServiceImpl implements IActorService {

	private IActorDao actorDao=new ActorDaoImplForDB();
	
	//method to get all actors
	@Override
	public List<Actor> getActors() {
		return actorDao.getActors();
	}

	//method to display all actors for search
	@Override
	public ArrayList<Actor> displayActors() {
		return  actorDao.displayActors();
	}

	@Override
	public int addActor(Actor actor) {
		return actorDao.addActor(actor);
	}

	@Override
	public Actor getActor(int actorId) {
		return actorDao.getActor(actorId);
	}

	@Override
	public int updateActor(Actor actor) {
		return actorDao.updateActor(actor);
	}

	@Override
	public int deleteActor(int actorId) {
		return actorDao.deleteActor(actorId);
	}


}

