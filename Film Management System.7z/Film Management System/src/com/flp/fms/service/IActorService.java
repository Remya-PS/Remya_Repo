package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

//Actor service interface
public interface IActorService {
	public List<Actor> getActors();
	
	public ArrayList<Actor> displayActors();
	
	public int addActor(Actor actor);

	public Actor getActor(int actorId);

	public int updateActor(Actor actor);

	public int deleteActor(int actorId);
}
