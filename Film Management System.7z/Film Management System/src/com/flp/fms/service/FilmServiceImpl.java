package com.flp.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


//Film Service Implementation
public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImplForDB();
	private IActorDao actorDao = new ActorDaoImplForDB();
	
	//method to get all languages
	@Override
	public List<Language> getLanguages() {
		return filmDao.getLanguages();
	}
	
	//method to get all category
	@Override
	public List<Category> getCategory() {
		return filmDao.getCategory();
	}	
	
	//method to get all actors
	@Override
	public List<Actor> getActors() {
			return actorDao.getActors();
		}	
	
	//method to add film
	@Override
	public void addFilm(Film film) {
		filmDao.addFilm(film);
		
	}
	
	//method to get all films added
	@Override
	public List<Film> getAllFilms() {
		return filmDao.getAllFilms();
	}
	
	//method to delete film 
	@Override
	public int removeFilm(int film_Id) {
		return filmDao.removeFilm(film_Id);
	}
	
	//method to display all languges for search
	@Override
	public ArrayList<Language> displayLanguages() {
		return filmDao.displayLanguages();
	}
	
	//method to display all category for search
	@Override
	public ArrayList<Category> displayCategory() {
		return filmDao.displayCategory();
	}
	
	//method to search all films
	@Override
	public ArrayList<Film> searchfilm(Film film) {
		return filmDao.searchfilm(film);
	}
	
	//method to update film
	@Override
	public Boolean updateFilm(Film film) {
		return filmDao.updateFilm(film);
	
	}

}


