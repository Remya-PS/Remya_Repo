package com.flp.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


//Film Service Interface
public interface IFilmService {
	
	public List<Language> getLanguages();
	
	public List<Category> getCategory();
	
	public List<Actor> getActors();
	
	public void addFilm(Film film);
	
	public List<Film> getAllFilms();
	
	public int removeFilm(int film_Id);
	
	public ArrayList<Language> displayLanguages();
	
	public ArrayList<Category> displayCategory();
	
	public ArrayList<Film> searchfilm(Film film);
	
	Boolean updateFilm(Film film);

}
