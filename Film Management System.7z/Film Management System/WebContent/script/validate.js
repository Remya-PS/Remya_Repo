
// function to validate user input in create film
function validateForm()
{
	var flag=true;
	var title=film.filmtitle.value;
	var length=film.length.value;
	var rate=film.rate.value;
	var cost = film.cost.value;
	
	//validate if title is null or empty or of required pattern
	if (title == null || title == ""||!isValidTitle()) {
       document.getElementById("title_val").innerHTML="*Please enter Film Name!";
        flag=false;
    }else
    	document.getElementById("title_val").innerHTML="";
	
	//validate if length is null or empty or of required pattern
	if(length==null||length==""||!isValidLength()){
		document.getElementById("length_val").innerHTML="*Please enter valid Film Length!";
        flag=false;
    }else
    	document.getElementById("length_val").innerHTML="";
	
	//validate if rating is null or empty or of required pattern
	if(rate==null||rate==""||!isValidRate()){
		document.getElementById("rate_val").innerHTML="*Please enter Rating between 1 and 5!";
        flag=false;
    }else
    	document.getElementById("rate_val").innerHTML="";
	
	//validate if rental duration is null or empty or of required pattern
	if(!isValidRentalDate()){
		
		document.getElementById("rental_val").innerHTML="*Rental Duration should be future date than Release Year";
		flag = false;
	}
		
	else
		document.getElementById("rental_val").innerHTML="";
	
	//validate if replacement cost is null or empty or of required pattern
	if(cost==""||cost==null||!isValidNumber()){
		document.getElementById("cost_val").innerHTML="*Only numbers are allowed!";
		flag = false;
	}
	else
		document.getElementById("cost_val").innerHTML="";
	
	return flag;
}

//validate if title is of required pattern
function isValidTitle(){
	
	var pattern=/[A-Za-z0-9@., ]+$/;
	
	if(document.getElementById("title").value.match(pattern))	
		return true;
	else
		return false;
}

//validate if length is of required pattern
function isValidLength(){
	var length=film.length.value;
	var length1=parseInt(length);
	if(length1>0 && length1<=1000)
		return true;
	else
		return false;
}

//validate if rating is of required range
function isValidRate(){
	var rate=film.rate.value;
	
	if(rate>0 && rate<=5)
		return true;
	else
		return false;
}

//validate if rental duration is greater than release date
function isValidRentalDate(){
	
	var releaseDate=new Date(film.reldate.value).getTime();
	var rentalduration=new Date(film.rendur.value).getTime();
	
	if(rentalduration >= releaseDate)
    	return true;
    else
    	return false;
}

//validate if replacement cost is of required pattern
function isValidNumber(){
	
	var numbers = /^[0-9]+(.)?[0-9]*$/;  
	var cost = film.cost.value;
	
    if(cost.match(numbers))  
    	return true;
    else
    	return false;
}

//confirmation to delete film
function deleteFilmConfirmation()
{
return confirm("Are you sure to delete the film?");
}

//Validation For Actor
function isValidActor()
{
var flag=true;
var actorFirstName=addActor.actorFirstName.value;
var actorLastName=addActor.actorLastName.value;

if(actorFirstName==""||actorFirstName==null)
	{
	document.getElementById("FirstName_Val").innerHTML="*Actor FirstName is Mandatory";
	flag=false;
	}
else
	document.getElementById("FirstName_Val").innerHTML="";
if(actorLastName==""||actorLastName==null)
	{
	document.getElementById("LastName_Val").innerHTML="*Actor LastName is Mandatory";
	flag=false;
	}
else
	document.getElementById("LastName_Val").innerHTML="";
return flag;
}


function deleteActorConfirmation()
{
return confirm("Are you sure to delete the actor?");
}

