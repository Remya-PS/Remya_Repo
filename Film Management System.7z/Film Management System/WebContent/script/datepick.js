
// For Date 1
$(function() {
            $( "#datepicker1" ).datepicker({
            		numberOfMonths:1,
            		showWeek:true,
            		changeMonth:true,
            		changeYear:true,
            		showButtonPanel:false,
            		minDate: new Date(2000,1 - 1,1),
            		maxDate: new Date(2016,12 - 1,31),
            		dateFormat:"dd-M-yy"});
            
            $( "#datepicker1" ).datepicker("show");
});
 
//For Date 2
$(function() {
             $( "#datepicker2" ).datepicker({
         		numberOfMonths:1,
        		showWeek:true,
        		changeMonth:true,
        		changeYear:true,
        		showButtonPanel:false,
        		minDate: new Date(2000,1 - 1,1),
        		maxDate: new Date(2016,12 - 1,31),
        		dateFormat:"dd-M-yy"});
             
             $( "#datepicker2" ).datepicker("show");
});
