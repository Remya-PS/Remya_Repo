package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDAO;
import com.flp.fms.domain.Actor;

//Actor Service Implementation
public class ActorServiceImpl implements IActorService {

	private IActorDAO actorDao = new ActorDaoImplForList();
	
	//method to get all actors
	@Override
	public List<Actor> getActors() {
		return actorDao.getActors();
	}

}
