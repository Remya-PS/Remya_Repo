package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

//Actor service interface
public interface IActorService {

	//Getting all Actors
	public List<Actor> getActors();
}
