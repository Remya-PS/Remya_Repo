package com.flp.fms.domain;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class Film {

	//private fields
	private int filmId;
	private String title;
	private String description;
	private Date releaseYear;
	private Language originalLanguage;
	private Set<Language> languages;
	private Date rentalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String specialFeatures;
	private Set<Actor> actors;
	private Category category;
	
	
	//no argument constructor
	public Film(){
		
	}


	//constructor with fields
	public Film(int filmId, String title, String description, Date releaseYear, Set<Language> languages,
			Language originalLanguage, Date rentalDuration, int length, double replacementCost, int ratings,
			String specialFeatures, Set<Actor> actors, Category category) {
		super();
		this.filmId = filmId;
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.rentalDuration = rentalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		this.specialFeatures = specialFeatures;
		this.actors = actors;
		this.category = category;
	}


	//Getters and Setters
	public int getFilmId() {
		return filmId;
	}


	public void setFilmId(int filmId) {
		this.filmId = filmId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getReleaseYear() {
		return releaseYear;
	}


	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}


	public Set<Language> getLanguages() {
		return languages;
	}


	public void setLanguages(Set<Language> languages) {
		this.languages = languages;
	}


	public Language getOriginalLanguage() {
		return originalLanguage;
	}


	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}


	public Date getRentalDuration() {
		return rentalDuration;
	}


	public void setRentalDuration(Date rentalDuration) {
		this.rentalDuration = rentalDuration;
	}


	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	public double getReplacementCost() {
		return replacementCost;
	}


	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}


	public int getRatings() {
		return ratings;
	}


	public void setRatings(int ratings) {
		this.ratings = ratings;
	}


	public String getSpecialFeatures() {
		return specialFeatures;
	}


	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}


	public Set<Actor> getActors() {
		return actors;
	}


	public void setActors(Set<Actor> actors) {
		this.actors = actors;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	
	//toString method implementation
	@Override
	public String toString() {
		return "Film [filmId=" + filmId + ", title=" + title + ", description=" + description + ", releaseYear="
				+ releaseYear + ", originalLanguage=" + originalLanguage + ", languages=" + languages
				+ ", rentalDuration=" + rentalDuration + ", length=" + length + ", replacementCost=" + replacementCost
				+ ", ratings=" + ratings + ", specialFeatures=" + specialFeatures + ", actors=" + actors + ", category="
				+ category + "]";
	}
	
	
}
