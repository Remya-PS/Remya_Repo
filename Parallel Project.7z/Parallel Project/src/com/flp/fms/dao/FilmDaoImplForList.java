package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//Film Dao Implementation
public class FilmDaoImplForList implements IFilmDao {

	HashMap<Integer, Film> filmRepository = new HashMap<>();
	
	// Adding languages to Language List
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages=new ArrayList<>();
		
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kannada"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		return languages;
	}

	// Adding Categories to Category List
	@Override
	public List<Category> getCategories() {
		
		List<Category> categories = new ArrayList<>();
		
		categories.add(new Category(1,"comedy"));
		categories.add(new Category(2,"romantic"));
		categories.add(new Category(3,"thriller"));
		categories.add(new Category(4,"suspense"));
		categories.add(new Category(5,"drama"));
		categories.add(new Category(6,"fiction"));
		
		return categories;
	}

	// Adding film to Film Repository
	@Override
	public void addFilm(Film film) {

		filmRepository.put(film.getFilmId(), film);
		
	}

	// Getting all films from Film Repository
	@Override
	public Map<Integer, Film> getAllFilm() {
		
		return filmRepository;
	}

	
	//Searching Film from film repository using Film Id
	@Override
	public Film searchFilm(int filmId) {
			
		return filmRepository.get(filmId);
	}
	
	
	//Searching Film from film repository using Film Title
	@Override
	public Film searchFilm(String title) {
		
		Film result = null;
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			if(film.getTitle().equals(title)){
				
				result = film;
				break;
			}
		}
		
		return result;
	}
	
	
	//Searching Film from film repository using Film Rating
	@Override
	public List<Film> searchFilmByRating(int rating) {

		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getRatings()==rating){
				
				selectedFilms.add(film);
			}
		}
		
		
		return selectedFilms;
	}

	
	//Searching Film from film repository using Language
	@Override
	public List<Film> searchFilm(Language language) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			//if original language and entered language are same
			if(film.getOriginalLanguage().getLanguageId() == language.getLanguageId()){
				
				selectedFilms.add(film);
			}
			
			//if film is released in entered language
			else{
				
				Set<Language> languages = new HashSet<>();
				languages = film.getLanguages();
				
				for(Language lang : languages){
					
					if(lang.getLanguageId()==language.getLanguageId()){
						
						selectedFilms.add(film);
					}
				}
			}
		
		}
		
		return selectedFilms;
	}
		
	
	
	//Searching Film from film repository using Actors
	@Override
	public List<Film> searchFilm(Actor actor) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();
			
			for(Actor act : actors){
				
				if(act.getActorId()==actor.getActorId()){
					
					selectedFilms.add(film);
				}
				
			}
		}
		
		
		return selectedFilms;
	}

		
	
	//Searching Film from film repository using Film Title,Release Date and Rating
	@Override
	public Film searchFilm(String title, Date releaseDate, int rating) {
		
		Film result=null;
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getTitle().equals(title) && film.getReleaseYear().equals(releaseDate) && film.getRatings()==rating){
				
				result =film;
				break;
			}
		}
		
		return result;
	}

	
	//Deleting film Using Film Id
	@Override
	public void removeFilm(int filmId) {
		
		filmRepository.remove(filmId);
		
	}

	//Deleting film Using Film Title
	@Override
	public void removeFilm(String title) {
		
		Collection<Film> allFilms = filmRepository.values();
		Iterator<Film> itr = allFilms.iterator();
		
		int filmId=0;
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getTitle().equals(title)){
				
				filmId = film.getFilmId();
				break;
			}
		}
		
		filmRepository.remove(filmId);	
	}
	

	
	//Deleting film Using Film Rating
	@Override
	public void removeFilmByRating(int rating) {
		
		Collection<Film> allFilms = filmRepository.values();
		Iterator<Film> itr = allFilms.iterator();
		
		Set<Integer> selectedFilmIds = new HashSet<>();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getRatings() == rating){
				
				selectedFilmIds.add(film.getFilmId());	
			}
		}
		
		for(Integer filmId : selectedFilmIds){
			
			filmRepository.remove(filmId);
		}
	}

	
	//Deleting film Using Actor
	@Override
	public void removeFilm(Actor actor) {
						
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		Set<Integer> selectedFilmIds = new HashSet<>();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			//getting the name of all actors in the film
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();
			
			for(Actor act : actors){
				
				if(act.getActorId() == actor.getActorId()){
					
					selectedFilmIds.add(film.getFilmId());
				}
				
			}
		}
		
		for(Integer filmId : selectedFilmIds){
			
			filmRepository.remove(filmId);
		}

	}

	
	//Updating The Film
	@Override
	public void updateFilm(Film film) {
			addFilm(film);
	}

}
