package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;

//Actor DAO Interface
public interface IActorDAO {

	public List<Actor> getActors();
}
