package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

//Actor Dao Implementation
public class ActorDaoImplForList implements IActorDAO {

	//Adding List of Actors
	@Override
	public List<Actor> getActors() {
		
		List<Actor> actors = new ArrayList<>();
		
		actors.add(new Actor(101, "Sharuk", "Khan"));
		actors.add(new Actor(102, "Aamir", "Khan"));
		actors.add(new Actor(103, "Deepika", "Padukon"));
		actors.add(new Actor(104, "Madhuri", "Dixit"));
		actors.add(new Actor(105, "Amitabh", "Bachan"));
		
		return actors;
	}

}
